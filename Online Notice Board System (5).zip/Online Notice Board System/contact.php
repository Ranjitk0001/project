<?php
 // echo "contact us";

?>
<!DOCTYPE html>
<html>
<head>
	<title>contact us</title>
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
		
		<div class="col-sm-8"> <br><br>
			<div class="panel panel-default">
  <div class="panel-heading">Contact Us</div>
  <div class="panel-body">


		Name: Ranjit Kale/Akash Kakade/ Rohan changude <br/>
		Mobile: 9421556019<br/>
		Email:onboard01@gmail.com<br/>
		Website: <a href="http://www.w3schools.com/">W3Schools</a>
		</div>
	</div>
	</div>
	</div>
</body>
</html>